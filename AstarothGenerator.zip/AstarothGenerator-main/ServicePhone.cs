﻿public enum ServicePhone
{
    FiveSIM, SMSPVA
}