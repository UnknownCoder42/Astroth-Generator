# AstarothGenerator
A Discord account generator. MADE FOR EDUCATIONAL PURPOSE ONLY.
