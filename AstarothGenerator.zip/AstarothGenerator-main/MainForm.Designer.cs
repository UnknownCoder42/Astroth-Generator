﻿partial class MainForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.gunaControlBox1 = new Guna.UI.WinForms.GunaControlBox();
            this.gunaControlBox2 = new Guna.UI.WinForms.GunaControlBox();
            this.firefoxMainTabControl1 = new FirefoxMainTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.metroLabel32 = new MetroSuite.MetroLabel();
            this.gunaButton16 = new Guna.UI.WinForms.GunaButton();
            this.siticoneSlider1 = new ns1.SiticoneSlider();
            this.metroLabel14 = new MetroSuite.MetroLabel();
            this.gunaTextBox1 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton4 = new Guna.UI.WinForms.GunaButton();
            this.metroLabel13 = new MetroSuite.MetroLabel();
            this.metroLabel12 = new MetroSuite.MetroLabel();
            this.metroLabel11 = new MetroSuite.MetroLabel();
            this.metroLabel9 = new MetroSuite.MetroLabel();
            this.metroLabel10 = new MetroSuite.MetroLabel();
            this.metroLabel7 = new MetroSuite.MetroLabel();
            this.metroLabel8 = new MetroSuite.MetroLabel();
            this.metroLabel5 = new MetroSuite.MetroLabel();
            this.metroLabel6 = new MetroSuite.MetroLabel();
            this.metroLabel3 = new MetroSuite.MetroLabel();
            this.metroLabel4 = new MetroSuite.MetroLabel();
            this.metroLabel2 = new MetroSuite.MetroLabel();
            this.metroLabel1 = new MetroSuite.MetroLabel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.metroLabel29 = new MetroSuite.MetroLabel();
            this.metroLabel30 = new MetroSuite.MetroLabel();
            this.siticoneCheckBox14 = new ns1.SiticoneCheckBox();
            this.gunaButton9 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton7 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton8 = new Guna.UI.WinForms.GunaButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.siticoneRadioButton12 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton13 = new ns1.SiticoneRadioButton();
            this.metroLabel21 = new MetroSuite.MetroLabel();
            this.gunaButton5 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton6 = new Guna.UI.WinForms.GunaButton();
            this.gunaLineTextBox6 = new Guna.UI.WinForms.GunaLineTextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.siticoneRadioButton9 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton10 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton11 = new ns1.SiticoneRadioButton();
            this.metroLabel20 = new MetroSuite.MetroLabel();
            this.gunaButton3 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.gunaLineTextBox5 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox4 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox3 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox2 = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaLineTextBox1 = new Guna.UI.WinForms.GunaLineTextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.siticoneRadioButton6 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton7 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton8 = new ns1.SiticoneRadioButton();
            this.metroLabel19 = new MetroSuite.MetroLabel();
            this.siticoneCheckBox9 = new ns1.SiticoneCheckBox();
            this.metroLabel18 = new MetroSuite.MetroLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.siticoneRadioButton5 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton4 = new ns1.SiticoneRadioButton();
            this.siticoneCheckBox7 = new ns1.SiticoneCheckBox();
            this.metroLabel17 = new MetroSuite.MetroLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.siticoneRadioButton2 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton1 = new ns1.SiticoneRadioButton();
            this.siticoneCheckBox6 = new ns1.SiticoneCheckBox();
            this.metroLabel16 = new MetroSuite.MetroLabel();
            this.siticoneCheckBox5 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox4 = new ns1.SiticoneCheckBox();
            this.metroLabel15 = new MetroSuite.MetroLabel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.siticoneCheckBox2 = new ns1.SiticoneCheckBox();
            this.gunaLineTextBox9 = new Guna.UI.WinForms.GunaLineTextBox();
            this.metroLabel31 = new MetroSuite.MetroLabel();
            this.siticoneCheckBox15 = new ns1.SiticoneCheckBox();
            this.siticoneCheckBox13 = new ns1.SiticoneCheckBox();
            this.metroLabel26 = new MetroSuite.MetroLabel();
            this.metroLabel25 = new MetroSuite.MetroLabel();
            this.gunaButton14 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton15 = new Guna.UI.WinForms.GunaButton();
            this.siticoneComboBox1 = new ns1.SiticoneComboBox();
            this.gunaLineTextBox8 = new Guna.UI.WinForms.GunaLineTextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.siticoneRadioButton26 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton29 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton30 = new ns1.SiticoneRadioButton();
            this.metroLabel28 = new MetroSuite.MetroLabel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.siticoneRadioButton27 = new ns1.SiticoneRadioButton();
            this.siticoneRadioButton28 = new ns1.SiticoneRadioButton();
            this.metroLabel27 = new MetroSuite.MetroLabel();
            this.gunaButton13 = new Guna.UI.WinForms.GunaButton();
            this.gunaLineTextBox7 = new Guna.UI.WinForms.GunaLineTextBox();
            this.siticoneCheckBox3 = new ns1.SiticoneCheckBox();
            this.metroLabel24 = new MetroSuite.MetroLabel();
            this.gunaButton11 = new Guna.UI.WinForms.GunaButton();
            this.metroLabel23 = new MetroSuite.MetroLabel();
            this.gunaButton10 = new Guna.UI.WinForms.GunaButton();
            this.siticoneCheckBox1 = new ns1.SiticoneCheckBox();
            this.metroLabel22 = new MetroSuite.MetroLabel();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.firefoxMainTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // gunaControlBox1
            // 
            this.gunaControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox1.Animated = true;
            this.gunaControlBox1.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox1.AnimationSpeed = 0.03F;
            this.gunaControlBox1.IconColor = System.Drawing.Color.White;
            this.gunaControlBox1.IconSize = 15F;
            this.gunaControlBox1.Location = new System.Drawing.Point(833, 8);
            this.gunaControlBox1.Name = "gunaControlBox1";
            this.gunaControlBox1.OnHoverBackColor = System.Drawing.Color.Red;
            this.gunaControlBox1.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox1.Size = new System.Drawing.Size(45, 29);
            this.gunaControlBox1.TabIndex = 0;
            // 
            // gunaControlBox2
            // 
            this.gunaControlBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox2.Animated = true;
            this.gunaControlBox2.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox2.AnimationSpeed = 0.03F;
            this.gunaControlBox2.ControlBoxType = Guna.UI.WinForms.FormControlBoxType.MinimizeBox;
            this.gunaControlBox2.IconColor = System.Drawing.Color.White;
            this.gunaControlBox2.IconSize = 15F;
            this.gunaControlBox2.Location = new System.Drawing.Point(782, 8);
            this.gunaControlBox2.Name = "gunaControlBox2";
            this.gunaControlBox2.OnHoverBackColor = System.Drawing.Color.Red;
            this.gunaControlBox2.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox2.Size = new System.Drawing.Size(45, 29);
            this.gunaControlBox2.TabIndex = 1;
            // 
            // firefoxMainTabControl1
            // 
            this.firefoxMainTabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.firefoxMainTabControl1.Controls.Add(this.tabPage1);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage2);
            this.firefoxMainTabControl1.Controls.Add(this.tabPage3);
            this.firefoxMainTabControl1.ItemSize = new System.Drawing.Size(43, 180);
            this.firefoxMainTabControl1.Location = new System.Drawing.Point(1, 38);
            this.firefoxMainTabControl1.Multiline = true;
            this.firefoxMainTabControl1.Name = "firefoxMainTabControl1";
            this.firefoxMainTabControl1.SelectedIndex = 0;
            this.firefoxMainTabControl1.Size = new System.Drawing.Size(881, 632);
            this.firefoxMainTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.firefoxMainTabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage1.Controls.Add(this.metroLabel32);
            this.tabPage1.Controls.Add(this.gunaButton16);
            this.tabPage1.Controls.Add(this.siticoneSlider1);
            this.tabPage1.Controls.Add(this.metroLabel14);
            this.tabPage1.Controls.Add(this.gunaTextBox1);
            this.tabPage1.Controls.Add(this.gunaButton1);
            this.tabPage1.Controls.Add(this.gunaButton4);
            this.tabPage1.Controls.Add(this.metroLabel13);
            this.tabPage1.Controls.Add(this.metroLabel12);
            this.tabPage1.Controls.Add(this.metroLabel11);
            this.tabPage1.Controls.Add(this.metroLabel9);
            this.tabPage1.Controls.Add(this.metroLabel10);
            this.tabPage1.Controls.Add(this.metroLabel7);
            this.tabPage1.Controls.Add(this.metroLabel8);
            this.tabPage1.Controls.Add(this.metroLabel5);
            this.tabPage1.Controls.Add(this.metroLabel6);
            this.tabPage1.Controls.Add(this.metroLabel3);
            this.tabPage1.Controls.Add(this.metroLabel4);
            this.tabPage1.Controls.Add(this.metroLabel2);
            this.tabPage1.Controls.Add(this.metroLabel1);
            this.tabPage1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage1.Location = new System.Drawing.Point(184, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(693, 624);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Dashboard";
            // 
            // metroLabel32
            // 
            this.metroLabel32.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel32.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel32.Location = new System.Drawing.Point(186, 97);
            this.metroLabel32.Name = "metroLabel32";
            this.metroLabel32.Size = new System.Drawing.Size(469, 23);
            this.metroLabel32.TabIndex = 23;
            this.metroLabel32.Text = "NOTE: Use threads at your own risk.";
            this.metroLabel32.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // gunaButton16
            // 
            this.gunaButton16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton16.Animated = true;
            this.gunaButton16.AnimationHoverSpeed = 0.07F;
            this.gunaButton16.AnimationSpeed = 0.03F;
            this.gunaButton16.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton16.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton16.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton16.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton16.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton16.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton16.ForeColor = System.Drawing.Color.White;
            this.gunaButton16.Image = null;
            this.gunaButton16.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton16.Location = new System.Drawing.Point(437, 193);
            this.gunaButton16.Name = "gunaButton16";
            this.gunaButton16.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton16.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton16.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton16.OnHoverImage = null;
            this.gunaButton16.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton16.Size = new System.Drawing.Size(199, 42);
            this.gunaButton16.TabIndex = 22;
            this.gunaButton16.Text = "Reload informations";
            this.gunaButton16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton16.Click += new System.EventHandler(this.gunaButton16_Click);
            // 
            // siticoneSlider1
            // 
            this.siticoneSlider1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneSlider1.Location = new System.Drawing.Point(32, 123);
            this.siticoneSlider1.Minimum = 1;
            this.siticoneSlider1.Name = "siticoneSlider1";
            this.siticoneSlider1.Size = new System.Drawing.Size(623, 60);
            this.siticoneSlider1.TabIndex = 21;
            this.siticoneSlider1.ThumbColor = System.Drawing.Color.Red;
            this.siticoneSlider1.Value = 1;
            this.siticoneSlider1.Scroll += new System.EventHandler(this.siticoneSlider1_Scroll);
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel14.Location = new System.Drawing.Point(29, 290);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(87, 15);
            this.metroLabel14.TabIndex = 20;
            this.metroLabel14.Text = "Tokens output";
            // 
            // gunaTextBox1
            // 
            this.gunaTextBox1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox1.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox1.BorderSize = 1;
            this.gunaTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox1.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaTextBox1.FocusedBorderColor = System.Drawing.Color.Red;
            this.gunaTextBox1.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.gunaTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox1.Location = new System.Drawing.Point(32, 323);
            this.gunaTextBox1.MaxLength = 2147483647;
            this.gunaTextBox1.MultiLine = true;
            this.gunaTextBox1.Name = "gunaTextBox1";
            this.gunaTextBox1.PasswordChar = '\0';
            this.gunaTextBox1.ReadOnly = true;
            this.gunaTextBox1.Size = new System.Drawing.Size(622, 198);
            this.gunaTextBox1.TabIndex = 19;
            // 
            // gunaButton1
            // 
            this.gunaButton1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton1.Animated = true;
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton1.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.Enabled = false;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = null;
            this.gunaButton1.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton1.Location = new System.Drawing.Point(346, 544);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Size = new System.Drawing.Size(308, 42);
            this.gunaButton1.TabIndex = 18;
            this.gunaButton1.Text = "Stop Generating";
            this.gunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // gunaButton4
            // 
            this.gunaButton4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton4.Animated = true;
            this.gunaButton4.AnimationHoverSpeed = 0.07F;
            this.gunaButton4.AnimationSpeed = 0.03F;
            this.gunaButton4.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton4.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton4.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton4.ForeColor = System.Drawing.Color.White;
            this.gunaButton4.Image = null;
            this.gunaButton4.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton4.Location = new System.Drawing.Point(32, 544);
            this.gunaButton4.Name = "gunaButton4";
            this.gunaButton4.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton4.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton4.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton4.OnHoverImage = null;
            this.gunaButton4.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton4.Size = new System.Drawing.Size(308, 42);
            this.gunaButton4.TabIndex = 17;
            this.gunaButton4.Text = "Start Generating";
            this.gunaButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton4.Click += new System.EventHandler(this.gunaButton4_Click);
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel13.Location = new System.Drawing.Point(29, 213);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(106, 60);
            this.metroLabel13.TabIndex = 13;
            this.metroLabel13.Text = "Captcha service: /\r\nCaptcha balance: /\r\nPhone service: /\r\nPhone balance: /";
            this.metroLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel12.Location = new System.Drawing.Point(29, 193);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(106, 15);
            this.metroLabel12.TabIndex = 12;
            this.metroLabel12.Text = "Your informations";
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel11.Location = new System.Drawing.Point(29, 100);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(151, 15);
            this.metroLabel11.TabIndex = 10;
            this.metroLabel11.Text = "Threads of generation: (1)";
            // 
            // metroLabel9
            // 
            this.metroLabel9.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel9.Location = new System.Drawing.Point(555, 45);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(100, 23);
            this.metroLabel9.TabIndex = 9;
            this.metroLabel9.Text = "0";
            this.metroLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel10.Location = new System.Drawing.Point(555, 21);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(100, 15);
            this.metroLabel10.TabIndex = 8;
            this.metroLabel10.Text = "Operations Exec.";
            // 
            // metroLabel7
            // 
            this.metroLabel7.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel7.Location = new System.Drawing.Point(432, 45);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(96, 23);
            this.metroLabel7.TabIndex = 7;
            this.metroLabel7.Text = "0";
            this.metroLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel8.Location = new System.Drawing.Point(432, 21);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(96, 15);
            this.metroLabel8.TabIndex = 6;
            this.metroLabel8.Text = "Generation Fails";
            // 
            // metroLabel5
            // 
            this.metroLabel5.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel5.Location = new System.Drawing.Point(316, 45);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(77, 23);
            this.metroLabel5.TabIndex = 5;
            this.metroLabel5.Text = "0";
            this.metroLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel6.Location = new System.Drawing.Point(316, 21);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(77, 15);
            this.metroLabel6.TabIndex = 4;
            this.metroLabel6.Text = "Captcha Fails";
            // 
            // metroLabel3
            // 
            this.metroLabel3.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel3.Location = new System.Drawing.Point(181, 45);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(97, 23);
            this.metroLabel3.TabIndex = 3;
            this.metroLabel3.Text = "0";
            this.metroLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel4.Location = new System.Drawing.Point(181, 21);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(97, 15);
            this.metroLabel4.TabIndex = 2;
            this.metroLabel4.Text = "Captcha Success";
            // 
            // metroLabel2
            // 
            this.metroLabel2.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel2.Location = new System.Drawing.Point(32, 45);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(106, 23);
            this.metroLabel2.TabIndex = 1;
            this.metroLabel2.Text = "0";
            this.metroLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel1.Location = new System.Drawing.Point(29, 21);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(109, 15);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "Tokens Generated";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage2.Controls.Add(this.metroLabel29);
            this.tabPage2.Controls.Add(this.metroLabel30);
            this.tabPage2.Controls.Add(this.siticoneCheckBox14);
            this.tabPage2.Controls.Add(this.gunaButton9);
            this.tabPage2.Controls.Add(this.gunaButton7);
            this.tabPage2.Controls.Add(this.gunaButton8);
            this.tabPage2.Controls.Add(this.panel5);
            this.tabPage2.Controls.Add(this.metroLabel21);
            this.tabPage2.Controls.Add(this.gunaButton5);
            this.tabPage2.Controls.Add(this.gunaButton6);
            this.tabPage2.Controls.Add(this.gunaLineTextBox6);
            this.tabPage2.Controls.Add(this.panel4);
            this.tabPage2.Controls.Add(this.metroLabel20);
            this.tabPage2.Controls.Add(this.gunaButton3);
            this.tabPage2.Controls.Add(this.gunaButton2);
            this.tabPage2.Controls.Add(this.gunaLineTextBox5);
            this.tabPage2.Controls.Add(this.gunaLineTextBox4);
            this.tabPage2.Controls.Add(this.gunaLineTextBox3);
            this.tabPage2.Controls.Add(this.gunaLineTextBox2);
            this.tabPage2.Controls.Add(this.gunaLineTextBox1);
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Controls.Add(this.metroLabel19);
            this.tabPage2.Controls.Add(this.siticoneCheckBox9);
            this.tabPage2.Controls.Add(this.metroLabel18);
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Controls.Add(this.siticoneCheckBox7);
            this.tabPage2.Controls.Add(this.metroLabel17);
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Controls.Add(this.siticoneCheckBox6);
            this.tabPage2.Controls.Add(this.metroLabel16);
            this.tabPage2.Controls.Add(this.siticoneCheckBox5);
            this.tabPage2.Controls.Add(this.siticoneCheckBox4);
            this.tabPage2.Controls.Add(this.metroLabel15);
            this.tabPage2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage2.Location = new System.Drawing.Point(184, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(693, 624);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Gen Settings";
            // 
            // metroLabel29
            // 
            this.metroLabel29.AutoSize = true;
            this.metroLabel29.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel29.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel29.Location = new System.Drawing.Point(15, 503);
            this.metroLabel29.Name = "metroLabel29";
            this.metroLabel29.Size = new System.Drawing.Size(118, 45);
            this.metroLabel29.TabIndex = 71;
            this.metroLabel29.Text = "Loaded usernames: 0\r\nLoaded passwords: 0\r\nLoaded avatars: 0";
            this.metroLabel29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // metroLabel30
            // 
            this.metroLabel30.AutoSize = true;
            this.metroLabel30.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel30.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel30.Location = new System.Drawing.Point(15, 485);
            this.metroLabel30.Name = "metroLabel30";
            this.metroLabel30.Size = new System.Drawing.Size(79, 15);
            this.metroLabel30.TabIndex = 70;
            this.metroLabel30.Text = "Informations";
            // 
            // siticoneCheckBox14
            // 
            this.siticoneCheckBox14.AutoSize = true;
            this.siticoneCheckBox14.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox14.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox14.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox14.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox14.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox14.Location = new System.Drawing.Point(410, 399);
            this.siticoneCheckBox14.Name = "siticoneCheckBox14";
            this.siticoneCheckBox14.Size = new System.Drawing.Size(115, 17);
            this.siticoneCheckBox14.TabIndex = 38;
            this.siticoneCheckBox14.Text = "Set Avatar Picture";
            this.siticoneCheckBox14.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox14.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox14.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox14.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox14.UseVisualStyleBackColor = true;
            // 
            // gunaButton9
            // 
            this.gunaButton9.Animated = true;
            this.gunaButton9.AnimationHoverSpeed = 0.07F;
            this.gunaButton9.AnimationSpeed = 0.03F;
            this.gunaButton9.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton9.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton9.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton9.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton9.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton9.ForeColor = System.Drawing.Color.White;
            this.gunaButton9.Image = null;
            this.gunaButton9.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton9.Location = new System.Drawing.Point(410, 488);
            this.gunaButton9.Name = "gunaButton9";
            this.gunaButton9.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton9.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton9.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton9.OnHoverImage = null;
            this.gunaButton9.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton9.Size = new System.Drawing.Size(266, 42);
            this.gunaButton9.TabIndex = 37;
            this.gunaButton9.Text = "Load specified avatar";
            this.gunaButton9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton9.Click += new System.EventHandler(this.gunaButton9_Click);
            // 
            // gunaButton7
            // 
            this.gunaButton7.Animated = true;
            this.gunaButton7.AnimationHoverSpeed = 0.07F;
            this.gunaButton7.AnimationSpeed = 0.03F;
            this.gunaButton7.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton7.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton7.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton7.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton7.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton7.ForeColor = System.Drawing.Color.White;
            this.gunaButton7.Image = null;
            this.gunaButton7.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton7.Location = new System.Drawing.Point(546, 536);
            this.gunaButton7.Name = "gunaButton7";
            this.gunaButton7.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton7.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton7.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton7.OnHoverImage = null;
            this.gunaButton7.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton7.Size = new System.Drawing.Size(130, 42);
            this.gunaButton7.TabIndex = 36;
            this.gunaButton7.Text = "Reset list";
            this.gunaButton7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton7.Click += new System.EventHandler(this.gunaButton7_Click);
            // 
            // gunaButton8
            // 
            this.gunaButton8.Animated = true;
            this.gunaButton8.AnimationHoverSpeed = 0.07F;
            this.gunaButton8.AnimationSpeed = 0.03F;
            this.gunaButton8.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton8.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton8.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton8.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton8.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton8.ForeColor = System.Drawing.Color.White;
            this.gunaButton8.Image = null;
            this.gunaButton8.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton8.Location = new System.Drawing.Point(410, 536);
            this.gunaButton8.Name = "gunaButton8";
            this.gunaButton8.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton8.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton8.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton8.OnHoverImage = null;
            this.gunaButton8.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton8.Size = new System.Drawing.Size(130, 42);
            this.gunaButton8.TabIndex = 35;
            this.gunaButton8.Text = "Load list";
            this.gunaButton8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton8.Click += new System.EventHandler(this.gunaButton8_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.siticoneRadioButton12);
            this.panel5.Controls.Add(this.siticoneRadioButton13);
            this.panel5.Location = new System.Drawing.Point(410, 422);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(183, 60);
            this.panel5.TabIndex = 33;
            // 
            // siticoneRadioButton12
            // 
            this.siticoneRadioButton12.AutoSize = true;
            this.siticoneRadioButton12.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton12.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton12.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton12.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton12.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton12.Location = new System.Drawing.Point(0, 31);
            this.siticoneRadioButton12.Name = "siticoneRadioButton12";
            this.siticoneRadioButton12.Size = new System.Drawing.Size(142, 17);
            this.siticoneRadioButton12.TabIndex = 2;
            this.siticoneRadioButton12.Text = "Pick random from a list";
            this.siticoneRadioButton12.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton12.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton12.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton12.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton12.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton13
            // 
            this.siticoneRadioButton13.AutoSize = true;
            this.siticoneRadioButton13.Checked = true;
            this.siticoneRadioButton13.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton13.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton13.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton13.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton13.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton13.Location = new System.Drawing.Point(0, 8);
            this.siticoneRadioButton13.Name = "siticoneRadioButton13";
            this.siticoneRadioButton13.Size = new System.Drawing.Size(107, 17);
            this.siticoneRadioButton13.TabIndex = 1;
            this.siticoneRadioButton13.TabStop = true;
            this.siticoneRadioButton13.Text = "Specified Avatar";
            this.siticoneRadioButton13.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton13.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton13.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton13.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton13.UseVisualStyleBackColor = true;
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel21.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel21.Location = new System.Drawing.Point(407, 379);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(93, 15);
            this.metroLabel21.TabIndex = 32;
            this.metroLabel21.Text = "Avatar Settings";
            // 
            // gunaButton5
            // 
            this.gunaButton5.Animated = true;
            this.gunaButton5.AnimationHoverSpeed = 0.07F;
            this.gunaButton5.AnimationSpeed = 0.03F;
            this.gunaButton5.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton5.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton5.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton5.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton5.ForeColor = System.Drawing.Color.White;
            this.gunaButton5.Image = null;
            this.gunaButton5.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton5.Location = new System.Drawing.Point(546, 330);
            this.gunaButton5.Name = "gunaButton5";
            this.gunaButton5.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton5.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton5.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton5.OnHoverImage = null;
            this.gunaButton5.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton5.Size = new System.Drawing.Size(130, 42);
            this.gunaButton5.TabIndex = 31;
            this.gunaButton5.Text = "Reset list";
            this.gunaButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton5.Click += new System.EventHandler(this.gunaButton5_Click);
            // 
            // gunaButton6
            // 
            this.gunaButton6.Animated = true;
            this.gunaButton6.AnimationHoverSpeed = 0.07F;
            this.gunaButton6.AnimationSpeed = 0.03F;
            this.gunaButton6.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton6.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton6.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton6.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton6.ForeColor = System.Drawing.Color.White;
            this.gunaButton6.Image = null;
            this.gunaButton6.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton6.Location = new System.Drawing.Point(410, 330);
            this.gunaButton6.Name = "gunaButton6";
            this.gunaButton6.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton6.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton6.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton6.OnHoverImage = null;
            this.gunaButton6.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton6.Size = new System.Drawing.Size(130, 42);
            this.gunaButton6.TabIndex = 30;
            this.gunaButton6.Text = "Load list";
            this.gunaButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton6.Click += new System.EventHandler(this.gunaButton6_Click);
            // 
            // gunaLineTextBox6
            // 
            this.gunaLineTextBox6.Animated = true;
            this.gunaLineTextBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox6.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox6.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox6.LineSize = 1;
            this.gunaLineTextBox6.Location = new System.Drawing.Point(410, 298);
            this.gunaLineTextBox6.Name = "gunaLineTextBox6";
            this.gunaLineTextBox6.PasswordChar = '\0';
            this.gunaLineTextBox6.Size = new System.Drawing.Size(266, 26);
            this.gunaLineTextBox6.TabIndex = 29;
            this.gunaLineTextBox6.Text = "Insert specified password here.";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.siticoneRadioButton9);
            this.panel4.Controls.Add(this.siticoneRadioButton10);
            this.panel4.Controls.Add(this.siticoneRadioButton11);
            this.panel4.Location = new System.Drawing.Point(410, 214);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(183, 77);
            this.panel4.TabIndex = 28;
            // 
            // siticoneRadioButton9
            // 
            this.siticoneRadioButton9.AutoSize = true;
            this.siticoneRadioButton9.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton9.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton9.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton9.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton9.Location = new System.Drawing.Point(0, 49);
            this.siticoneRadioButton9.Name = "siticoneRadioButton9";
            this.siticoneRadioButton9.Size = new System.Drawing.Size(142, 17);
            this.siticoneRadioButton9.TabIndex = 2;
            this.siticoneRadioButton9.Text = "Pick random from a list";
            this.siticoneRadioButton9.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton9.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton9.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton9.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton9.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton10
            // 
            this.siticoneRadioButton10.AutoSize = true;
            this.siticoneRadioButton10.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton10.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton10.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton10.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton10.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton10.Location = new System.Drawing.Point(0, 26);
            this.siticoneRadioButton10.Name = "siticoneRadioButton10";
            this.siticoneRadioButton10.Size = new System.Drawing.Size(124, 17);
            this.siticoneRadioButton10.TabIndex = 1;
            this.siticoneRadioButton10.Text = "Specified Password";
            this.siticoneRadioButton10.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton10.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton10.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton10.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton10.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton11
            // 
            this.siticoneRadioButton11.AutoSize = true;
            this.siticoneRadioButton11.Checked = true;
            this.siticoneRadioButton11.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton11.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton11.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton11.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton11.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton11.Location = new System.Drawing.Point(0, 3);
            this.siticoneRadioButton11.Name = "siticoneRadioButton11";
            this.siticoneRadioButton11.Size = new System.Drawing.Size(120, 17);
            this.siticoneRadioButton11.TabIndex = 0;
            this.siticoneRadioButton11.TabStop = true;
            this.siticoneRadioButton11.Text = "Random Password";
            this.siticoneRadioButton11.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton11.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton11.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton11.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton11.UseVisualStyleBackColor = true;
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel20.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel20.Location = new System.Drawing.Point(407, 196);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(108, 15);
            this.metroLabel20.TabIndex = 27;
            this.metroLabel20.Text = "Password Settings";
            // 
            // gunaButton3
            // 
            this.gunaButton3.Animated = true;
            this.gunaButton3.AnimationHoverSpeed = 0.07F;
            this.gunaButton3.AnimationSpeed = 0.03F;
            this.gunaButton3.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton3.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton3.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton3.ForeColor = System.Drawing.Color.White;
            this.gunaButton3.Image = null;
            this.gunaButton3.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton3.Location = new System.Drawing.Point(546, 148);
            this.gunaButton3.Name = "gunaButton3";
            this.gunaButton3.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton3.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton3.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton3.OnHoverImage = null;
            this.gunaButton3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton3.Size = new System.Drawing.Size(130, 42);
            this.gunaButton3.TabIndex = 26;
            this.gunaButton3.Text = "Reset list";
            this.gunaButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton3.Click += new System.EventHandler(this.gunaButton3_Click);
            // 
            // gunaButton2
            // 
            this.gunaButton2.Animated = true;
            this.gunaButton2.AnimationHoverSpeed = 0.07F;
            this.gunaButton2.AnimationSpeed = 0.03F;
            this.gunaButton2.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton2.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton2.ForeColor = System.Drawing.Color.White;
            this.gunaButton2.Image = null;
            this.gunaButton2.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton2.Location = new System.Drawing.Point(410, 148);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton2.Size = new System.Drawing.Size(130, 42);
            this.gunaButton2.TabIndex = 25;
            this.gunaButton2.Text = "Load list";
            this.gunaButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton2.Click += new System.EventHandler(this.gunaButton2_Click);
            // 
            // gunaLineTextBox5
            // 
            this.gunaLineTextBox5.Animated = true;
            this.gunaLineTextBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox5.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox5.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox5.LineSize = 1;
            this.gunaLineTextBox5.Location = new System.Drawing.Point(410, 116);
            this.gunaLineTextBox5.Name = "gunaLineTextBox5";
            this.gunaLineTextBox5.PasswordChar = '\0';
            this.gunaLineTextBox5.Size = new System.Drawing.Size(266, 26);
            this.gunaLineTextBox5.TabIndex = 24;
            this.gunaLineTextBox5.Text = "Insert specified username here.";
            // 
            // gunaLineTextBox4
            // 
            this.gunaLineTextBox4.Animated = true;
            this.gunaLineTextBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox4.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox4.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox4.LineSize = 1;
            this.gunaLineTextBox4.Location = new System.Drawing.Point(18, 447);
            this.gunaLineTextBox4.Name = "gunaLineTextBox4";
            this.gunaLineTextBox4.PasswordChar = '\0';
            this.gunaLineTextBox4.Size = new System.Drawing.Size(276, 26);
            this.gunaLineTextBox4.TabIndex = 23;
            this.gunaLineTextBox4.Text = "Insert limit of tokens to generate here.";
            // 
            // gunaLineTextBox3
            // 
            this.gunaLineTextBox3.Animated = true;
            this.gunaLineTextBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox3.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox3.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox3.LineSize = 1;
            this.gunaLineTextBox3.Location = new System.Drawing.Point(18, 415);
            this.gunaLineTextBox3.Name = "gunaLineTextBox3";
            this.gunaLineTextBox3.PasswordChar = '\0';
            this.gunaLineTextBox3.Size = new System.Drawing.Size(276, 26);
            this.gunaLineTextBox3.TabIndex = 22;
            this.gunaLineTextBox3.Text = "Insert phone service API key here.";
            // 
            // gunaLineTextBox2
            // 
            this.gunaLineTextBox2.Animated = true;
            this.gunaLineTextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox2.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox2.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox2.LineSize = 1;
            this.gunaLineTextBox2.Location = new System.Drawing.Point(18, 383);
            this.gunaLineTextBox2.Name = "gunaLineTextBox2";
            this.gunaLineTextBox2.PasswordChar = '\0';
            this.gunaLineTextBox2.Size = new System.Drawing.Size(276, 26);
            this.gunaLineTextBox2.TabIndex = 21;
            this.gunaLineTextBox2.Text = "Insert captcha service key here.";
            // 
            // gunaLineTextBox1
            // 
            this.gunaLineTextBox1.Animated = true;
            this.gunaLineTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox1.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox1.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox1.LineSize = 1;
            this.gunaLineTextBox1.Location = new System.Drawing.Point(18, 351);
            this.gunaLineTextBox1.Name = "gunaLineTextBox1";
            this.gunaLineTextBox1.PasswordChar = '\0';
            this.gunaLineTextBox1.Size = new System.Drawing.Size(276, 26);
            this.gunaLineTextBox1.TabIndex = 20;
            this.gunaLineTextBox1.Text = "Insert guild invite link / code here.";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.siticoneRadioButton6);
            this.panel3.Controls.Add(this.siticoneRadioButton7);
            this.panel3.Controls.Add(this.siticoneRadioButton8);
            this.panel3.Location = new System.Drawing.Point(414, 32);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(183, 77);
            this.panel3.TabIndex = 19;
            // 
            // siticoneRadioButton6
            // 
            this.siticoneRadioButton6.AutoSize = true;
            this.siticoneRadioButton6.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton6.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton6.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton6.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton6.Location = new System.Drawing.Point(0, 49);
            this.siticoneRadioButton6.Name = "siticoneRadioButton6";
            this.siticoneRadioButton6.Size = new System.Drawing.Size(142, 17);
            this.siticoneRadioButton6.TabIndex = 2;
            this.siticoneRadioButton6.Text = "Pick random from a list";
            this.siticoneRadioButton6.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton6.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton6.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton6.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton6.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton7
            // 
            this.siticoneRadioButton7.AutoSize = true;
            this.siticoneRadioButton7.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton7.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton7.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton7.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton7.Location = new System.Drawing.Point(0, 26);
            this.siticoneRadioButton7.Name = "siticoneRadioButton7";
            this.siticoneRadioButton7.Size = new System.Drawing.Size(126, 17);
            this.siticoneRadioButton7.TabIndex = 1;
            this.siticoneRadioButton7.Text = "Specified Username";
            this.siticoneRadioButton7.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton7.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton7.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton7.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton7.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton8
            // 
            this.siticoneRadioButton8.AutoSize = true;
            this.siticoneRadioButton8.Checked = true;
            this.siticoneRadioButton8.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton8.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton8.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton8.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton8.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton8.Location = new System.Drawing.Point(0, 3);
            this.siticoneRadioButton8.Name = "siticoneRadioButton8";
            this.siticoneRadioButton8.Size = new System.Drawing.Size(122, 17);
            this.siticoneRadioButton8.TabIndex = 0;
            this.siticoneRadioButton8.TabStop = true;
            this.siticoneRadioButton8.Text = "Random Username";
            this.siticoneRadioButton8.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton8.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton8.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton8.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton8.UseVisualStyleBackColor = true;
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel19.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel19.Location = new System.Drawing.Point(411, 14);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(113, 15);
            this.metroLabel19.TabIndex = 18;
            this.metroLabel19.Text = "Username Settings";
            // 
            // siticoneCheckBox9
            // 
            this.siticoneCheckBox9.AutoSize = true;
            this.siticoneCheckBox9.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox9.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox9.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox9.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox9.Location = new System.Drawing.Point(18, 324);
            this.siticoneCheckBox9.Name = "siticoneCheckBox9";
            this.siticoneCheckBox9.Size = new System.Drawing.Size(127, 17);
            this.siticoneCheckBox9.TabIndex = 15;
            this.siticoneCheckBox9.Text = "Verify email address";
            this.siticoneCheckBox9.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox9.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox9.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox9.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox9.UseVisualStyleBackColor = true;
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel18.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel18.Location = new System.Drawing.Point(15, 303);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(85, 15);
            this.metroLabel18.TabIndex = 14;
            this.metroLabel18.Text = "Email Settings";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.siticoneRadioButton5);
            this.panel2.Controls.Add(this.siticoneRadioButton4);
            this.panel2.Location = new System.Drawing.Point(3, 241);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(183, 51);
            this.panel2.TabIndex = 12;
            // 
            // siticoneRadioButton5
            // 
            this.siticoneRadioButton5.AutoSize = true;
            this.siticoneRadioButton5.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton5.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton5.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton5.Location = new System.Drawing.Point(15, 26);
            this.siticoneRadioButton5.Name = "siticoneRadioButton5";
            this.siticoneRadioButton5.Size = new System.Drawing.Size(126, 17);
            this.siticoneRadioButton5.TabIndex = 2;
            this.siticoneRadioButton5.Text = "Use SMSPVA Service";
            this.siticoneRadioButton5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton5.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton5.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton5.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton5.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton4
            // 
            this.siticoneRadioButton4.AutoSize = true;
            this.siticoneRadioButton4.Checked = true;
            this.siticoneRadioButton4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton4.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton4.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton4.Location = new System.Drawing.Point(15, 3);
            this.siticoneRadioButton4.Name = "siticoneRadioButton4";
            this.siticoneRadioButton4.Size = new System.Drawing.Size(110, 17);
            this.siticoneRadioButton4.TabIndex = 0;
            this.siticoneRadioButton4.TabStop = true;
            this.siticoneRadioButton4.Text = "Use 5SIM Service";
            this.siticoneRadioButton4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton4.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton4.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton4.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton4.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox7
            // 
            this.siticoneCheckBox7.AutoSize = true;
            this.siticoneCheckBox7.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox7.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox7.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox7.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox7.Location = new System.Drawing.Point(18, 218);
            this.siticoneCheckBox7.Name = "siticoneCheckBox7";
            this.siticoneCheckBox7.Size = new System.Drawing.Size(134, 17);
            this.siticoneCheckBox7.TabIndex = 11;
            this.siticoneCheckBox7.Text = "Verify phone number";
            this.siticoneCheckBox7.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox7.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox7.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox7.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox7.UseVisualStyleBackColor = true;
            this.siticoneCheckBox7.CheckedChanged += new System.EventHandler(this.siticoneCheckBox7_CheckedChanged);
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel17.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel17.Location = new System.Drawing.Point(15, 196);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(91, 15);
            this.metroLabel17.TabIndex = 10;
            this.metroLabel17.Text = "Phone Settings";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.siticoneRadioButton2);
            this.panel1.Controls.Add(this.siticoneRadioButton1);
            this.panel1.Location = new System.Drawing.Point(3, 132);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(183, 52);
            this.panel1.TabIndex = 9;
            // 
            // siticoneRadioButton2
            // 
            this.siticoneRadioButton2.AutoSize = true;
            this.siticoneRadioButton2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton2.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton2.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton2.Location = new System.Drawing.Point(15, 26);
            this.siticoneRadioButton2.Name = "siticoneRadioButton2";
            this.siticoneRadioButton2.Size = new System.Drawing.Size(148, 17);
            this.siticoneRadioButton2.TabIndex = 1;
            this.siticoneRadioButton2.Text = "Use CapMonster Service";
            this.siticoneRadioButton2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton2.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton2.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton2.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton2.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton1
            // 
            this.siticoneRadioButton1.AutoSize = true;
            this.siticoneRadioButton1.Checked = true;
            this.siticoneRadioButton1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton1.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton1.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton1.Location = new System.Drawing.Point(15, 3);
            this.siticoneRadioButton1.Name = "siticoneRadioButton1";
            this.siticoneRadioButton1.Size = new System.Drawing.Size(133, 17);
            this.siticoneRadioButton1.TabIndex = 0;
            this.siticoneRadioButton1.TabStop = true;
            this.siticoneRadioButton1.Text = "Use 2Captcha Service";
            this.siticoneRadioButton1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton1.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton1.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton1.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton1.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox6
            // 
            this.siticoneCheckBox6.AutoSize = true;
            this.siticoneCheckBox6.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox6.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox6.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox6.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox6.Location = new System.Drawing.Point(18, 114);
            this.siticoneCheckBox6.Name = "siticoneCheckBox6";
            this.siticoneCheckBox6.Size = new System.Drawing.Size(108, 17);
            this.siticoneCheckBox6.TabIndex = 8;
            this.siticoneCheckBox6.Text = "Bypass captchas";
            this.siticoneCheckBox6.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox6.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox6.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox6.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox6.UseVisualStyleBackColor = true;
            this.siticoneCheckBox6.CheckedChanged += new System.EventHandler(this.siticoneCheckBox6_CheckedChanged);
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel16.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel16.Location = new System.Drawing.Point(15, 92);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(100, 15);
            this.metroLabel16.TabIndex = 7;
            this.metroLabel16.Text = "Captcha Settings";
            // 
            // siticoneCheckBox5
            // 
            this.siticoneCheckBox5.AutoSize = true;
            this.siticoneCheckBox5.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox5.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox5.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox5.Location = new System.Drawing.Point(18, 58);
            this.siticoneCheckBox5.Name = "siticoneCheckBox5";
            this.siticoneCheckBox5.Size = new System.Drawing.Size(111, 17);
            this.siticoneCheckBox5.TabIndex = 6;
            this.siticoneCheckBox5.Text = "Limit Generation";
            this.siticoneCheckBox5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox5.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox5.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox5.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox5.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox4
            // 
            this.siticoneCheckBox4.AutoSize = true;
            this.siticoneCheckBox4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox4.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox4.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox4.Location = new System.Drawing.Point(18, 35);
            this.siticoneCheckBox4.Name = "siticoneCheckBox4";
            this.siticoneCheckBox4.Size = new System.Drawing.Size(99, 17);
            this.siticoneCheckBox4.TabIndex = 5;
            this.siticoneCheckBox4.Text = "Invite to Guild";
            this.siticoneCheckBox4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox4.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox4.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox4.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox4.UseVisualStyleBackColor = true;
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel15.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel15.Location = new System.Drawing.Point(15, 14);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(156, 15);
            this.metroLabel15.TabIndex = 1;
            this.metroLabel15.Text = "Token Generation Settings";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.tabPage3.Controls.Add(this.siticoneCheckBox2);
            this.tabPage3.Controls.Add(this.gunaLineTextBox9);
            this.tabPage3.Controls.Add(this.metroLabel31);
            this.tabPage3.Controls.Add(this.siticoneCheckBox15);
            this.tabPage3.Controls.Add(this.siticoneCheckBox13);
            this.tabPage3.Controls.Add(this.metroLabel26);
            this.tabPage3.Controls.Add(this.metroLabel25);
            this.tabPage3.Controls.Add(this.gunaButton14);
            this.tabPage3.Controls.Add(this.gunaButton15);
            this.tabPage3.Controls.Add(this.siticoneComboBox1);
            this.tabPage3.Controls.Add(this.gunaLineTextBox8);
            this.tabPage3.Controls.Add(this.panel8);
            this.tabPage3.Controls.Add(this.metroLabel28);
            this.tabPage3.Controls.Add(this.panel7);
            this.tabPage3.Controls.Add(this.metroLabel27);
            this.tabPage3.Controls.Add(this.gunaButton13);
            this.tabPage3.Controls.Add(this.gunaLineTextBox7);
            this.tabPage3.Controls.Add(this.siticoneCheckBox3);
            this.tabPage3.Controls.Add(this.metroLabel24);
            this.tabPage3.Controls.Add(this.gunaButton11);
            this.tabPage3.Controls.Add(this.metroLabel23);
            this.tabPage3.Controls.Add(this.gunaButton10);
            this.tabPage3.Controls.Add(this.siticoneCheckBox1);
            this.tabPage3.Controls.Add(this.metroLabel22);
            this.tabPage3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabPage3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.tabPage3.Location = new System.Drawing.Point(184, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(693, 624);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Misc Settings";
            // 
            // siticoneCheckBox2
            // 
            this.siticoneCheckBox2.AutoSize = true;
            this.siticoneCheckBox2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox2.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox2.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox2.Location = new System.Drawing.Point(412, 292);
            this.siticoneCheckBox2.Name = "siticoneCheckBox2";
            this.siticoneCheckBox2.Size = new System.Drawing.Size(212, 17);
            this.siticoneCheckBox2.TabIndex = 74;
            this.siticoneCheckBox2.Text = "Send generated tokens to webhook";
            this.siticoneCheckBox2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox2.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox2.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox2.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox2.UseVisualStyleBackColor = true;
            // 
            // gunaLineTextBox9
            // 
            this.gunaLineTextBox9.Animated = true;
            this.gunaLineTextBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox9.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox9.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox9.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox9.LineSize = 1;
            this.gunaLineTextBox9.Location = new System.Drawing.Point(412, 316);
            this.gunaLineTextBox9.Name = "gunaLineTextBox9";
            this.gunaLineTextBox9.PasswordChar = '\0';
            this.gunaLineTextBox9.Size = new System.Drawing.Size(266, 26);
            this.gunaLineTextBox9.TabIndex = 73;
            this.gunaLineTextBox9.Text = "Insert your Discord webhook here.";
            // 
            // metroLabel31
            // 
            this.metroLabel31.AutoSize = true;
            this.metroLabel31.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel31.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel31.Location = new System.Drawing.Point(409, 272);
            this.metroLabel31.Name = "metroLabel31";
            this.metroLabel31.Size = new System.Drawing.Size(61, 15);
            this.metroLabel31.TabIndex = 72;
            this.metroLabel31.Text = "Webhook";
            // 
            // siticoneCheckBox15
            // 
            this.siticoneCheckBox15.AutoSize = true;
            this.siticoneCheckBox15.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox15.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox15.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox15.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox15.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox15.Location = new System.Drawing.Point(412, 35);
            this.siticoneCheckBox15.Name = "siticoneCheckBox15";
            this.siticoneCheckBox15.Size = new System.Drawing.Size(96, 17);
            this.siticoneCheckBox15.TabIndex = 71;
            this.siticoneCheckBox15.Text = "Set About Me";
            this.siticoneCheckBox15.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox15.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox15.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox15.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox15.UseVisualStyleBackColor = true;
            // 
            // siticoneCheckBox13
            // 
            this.siticoneCheckBox13.AutoSize = true;
            this.siticoneCheckBox13.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox13.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox13.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox13.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox13.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox13.Location = new System.Drawing.Point(18, 339);
            this.siticoneCheckBox13.Name = "siticoneCheckBox13";
            this.siticoneCheckBox13.Size = new System.Drawing.Size(140, 17);
            this.siticoneCheckBox13.TabIndex = 70;
            this.siticoneCheckBox13.Text = "Set HypeSquad House";
            this.siticoneCheckBox13.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox13.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox13.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox13.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox13.UseVisualStyleBackColor = true;
            // 
            // metroLabel26
            // 
            this.metroLabel26.AutoSize = true;
            this.metroLabel26.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel26.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel26.Location = new System.Drawing.Point(409, 245);
            this.metroLabel26.Name = "metroLabel26";
            this.metroLabel26.Size = new System.Drawing.Size(112, 15);
            this.metroLabel26.TabIndex = 69;
            this.metroLabel26.Text = "Loaded about me: 0";
            this.metroLabel26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // metroLabel25
            // 
            this.metroLabel25.AutoSize = true;
            this.metroLabel25.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel25.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel25.Location = new System.Drawing.Point(409, 227);
            this.metroLabel25.Name = "metroLabel25";
            this.metroLabel25.Size = new System.Drawing.Size(79, 15);
            this.metroLabel25.TabIndex = 68;
            this.metroLabel25.Text = "Informations";
            // 
            // gunaButton14
            // 
            this.gunaButton14.Animated = true;
            this.gunaButton14.AnimationHoverSpeed = 0.07F;
            this.gunaButton14.AnimationSpeed = 0.03F;
            this.gunaButton14.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton14.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton14.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton14.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton14.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton14.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton14.ForeColor = System.Drawing.Color.White;
            this.gunaButton14.Image = null;
            this.gunaButton14.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton14.Location = new System.Drawing.Point(548, 175);
            this.gunaButton14.Name = "gunaButton14";
            this.gunaButton14.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton14.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton14.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton14.OnHoverImage = null;
            this.gunaButton14.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton14.Size = new System.Drawing.Size(130, 42);
            this.gunaButton14.TabIndex = 67;
            this.gunaButton14.Text = "Reset list";
            this.gunaButton14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton14.Click += new System.EventHandler(this.gunaButton14_Click);
            // 
            // gunaButton15
            // 
            this.gunaButton15.Animated = true;
            this.gunaButton15.AnimationHoverSpeed = 0.07F;
            this.gunaButton15.AnimationSpeed = 0.03F;
            this.gunaButton15.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton15.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton15.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton15.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton15.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton15.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton15.ForeColor = System.Drawing.Color.White;
            this.gunaButton15.Image = null;
            this.gunaButton15.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton15.Location = new System.Drawing.Point(412, 175);
            this.gunaButton15.Name = "gunaButton15";
            this.gunaButton15.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton15.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton15.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton15.OnHoverImage = null;
            this.gunaButton15.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton15.Size = new System.Drawing.Size(130, 42);
            this.gunaButton15.TabIndex = 66;
            this.gunaButton15.Text = "Load list";
            this.gunaButton15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton15.Click += new System.EventHandler(this.gunaButton15_Click);
            // 
            // siticoneComboBox1
            // 
            this.siticoneComboBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.siticoneComboBox1.BackColor = System.Drawing.Color.Transparent;
            this.siticoneComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.siticoneComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.siticoneComboBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.siticoneComboBox1.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneComboBox1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.siticoneComboBox1.ForeColor = System.Drawing.Color.White;
            this.siticoneComboBox1.FormattingEnabled = true;
            this.siticoneComboBox1.HoveredState.Parent = this.siticoneComboBox1;
            this.siticoneComboBox1.ItemHeight = 30;
            this.siticoneComboBox1.Items.AddRange(new object[] {
            "HypeSquad Balance",
            "HypeSquad Bravery",
            "HypeSquad Brilliance"});
            this.siticoneComboBox1.ItemsAppearance.Parent = this.siticoneComboBox1;
            this.siticoneComboBox1.Location = new System.Drawing.Point(18, 423);
            this.siticoneComboBox1.Name = "siticoneComboBox1";
            this.siticoneComboBox1.ShadowDecoration.Parent = this.siticoneComboBox1;
            this.siticoneComboBox1.Size = new System.Drawing.Size(276, 36);
            this.siticoneComboBox1.TabIndex = 65;
            // 
            // gunaLineTextBox8
            // 
            this.gunaLineTextBox8.Animated = true;
            this.gunaLineTextBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox8.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox8.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox8.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox8.LineSize = 1;
            this.gunaLineTextBox8.Location = new System.Drawing.Point(412, 143);
            this.gunaLineTextBox8.Name = "gunaLineTextBox8";
            this.gunaLineTextBox8.PasswordChar = '\0';
            this.gunaLineTextBox8.Size = new System.Drawing.Size(266, 26);
            this.gunaLineTextBox8.TabIndex = 64;
            this.gunaLineTextBox8.Text = "Insert specified about me here.";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.siticoneRadioButton26);
            this.panel8.Controls.Add(this.siticoneRadioButton29);
            this.panel8.Controls.Add(this.siticoneRadioButton30);
            this.panel8.Location = new System.Drawing.Point(412, 58);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(183, 77);
            this.panel8.TabIndex = 63;
            // 
            // siticoneRadioButton26
            // 
            this.siticoneRadioButton26.AutoSize = true;
            this.siticoneRadioButton26.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton26.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton26.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton26.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton26.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton26.Location = new System.Drawing.Point(0, 49);
            this.siticoneRadioButton26.Name = "siticoneRadioButton26";
            this.siticoneRadioButton26.Size = new System.Drawing.Size(142, 17);
            this.siticoneRadioButton26.TabIndex = 2;
            this.siticoneRadioButton26.Text = "Pick random from a list";
            this.siticoneRadioButton26.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton26.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton26.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton26.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton26.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton29
            // 
            this.siticoneRadioButton29.AutoSize = true;
            this.siticoneRadioButton29.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton29.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton29.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton29.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton29.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton29.Location = new System.Drawing.Point(0, 26);
            this.siticoneRadioButton29.Name = "siticoneRadioButton29";
            this.siticoneRadioButton29.Size = new System.Drawing.Size(126, 17);
            this.siticoneRadioButton29.TabIndex = 1;
            this.siticoneRadioButton29.Text = "Specified About Me";
            this.siticoneRadioButton29.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton29.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton29.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton29.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton29.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton30
            // 
            this.siticoneRadioButton30.AutoSize = true;
            this.siticoneRadioButton30.Checked = true;
            this.siticoneRadioButton30.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton30.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton30.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton30.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton30.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton30.Location = new System.Drawing.Point(0, 3);
            this.siticoneRadioButton30.Name = "siticoneRadioButton30";
            this.siticoneRadioButton30.Size = new System.Drawing.Size(122, 17);
            this.siticoneRadioButton30.TabIndex = 0;
            this.siticoneRadioButton30.TabStop = true;
            this.siticoneRadioButton30.Text = "Random About Me";
            this.siticoneRadioButton30.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton30.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton30.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton30.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton30.UseVisualStyleBackColor = true;
            // 
            // metroLabel28
            // 
            this.metroLabel28.AutoSize = true;
            this.metroLabel28.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel28.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel28.Location = new System.Drawing.Point(409, 14);
            this.metroLabel28.Name = "metroLabel28";
            this.metroLabel28.Size = new System.Drawing.Size(111, 15);
            this.metroLabel28.TabIndex = 62;
            this.metroLabel28.Text = "About Me Settings";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.siticoneRadioButton27);
            this.panel7.Controls.Add(this.siticoneRadioButton28);
            this.panel7.Location = new System.Drawing.Point(18, 362);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(183, 55);
            this.panel7.TabIndex = 61;
            // 
            // siticoneRadioButton27
            // 
            this.siticoneRadioButton27.AutoSize = true;
            this.siticoneRadioButton27.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton27.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton27.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton27.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton27.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton27.Location = new System.Drawing.Point(0, 26);
            this.siticoneRadioButton27.Name = "siticoneRadioButton27";
            this.siticoneRadioButton27.Size = new System.Drawing.Size(170, 17);
            this.siticoneRadioButton27.TabIndex = 1;
            this.siticoneRadioButton27.Text = "Specified HypeSquad House";
            this.siticoneRadioButton27.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton27.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton27.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton27.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton27.UseVisualStyleBackColor = true;
            // 
            // siticoneRadioButton28
            // 
            this.siticoneRadioButton28.AutoSize = true;
            this.siticoneRadioButton28.Checked = true;
            this.siticoneRadioButton28.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton28.CheckedState.BorderThickness = 0;
            this.siticoneRadioButton28.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneRadioButton28.CheckedState.InnerColor = System.Drawing.Color.White;
            this.siticoneRadioButton28.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneRadioButton28.Location = new System.Drawing.Point(0, 3);
            this.siticoneRadioButton28.Name = "siticoneRadioButton28";
            this.siticoneRadioButton28.Size = new System.Drawing.Size(166, 17);
            this.siticoneRadioButton28.TabIndex = 0;
            this.siticoneRadioButton28.TabStop = true;
            this.siticoneRadioButton28.Text = "Random HypeSquad House";
            this.siticoneRadioButton28.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneRadioButton28.UncheckedState.BorderThickness = 2;
            this.siticoneRadioButton28.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton28.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.siticoneRadioButton28.UseVisualStyleBackColor = true;
            // 
            // metroLabel27
            // 
            this.metroLabel27.AutoSize = true;
            this.metroLabel27.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel27.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel27.Location = new System.Drawing.Point(15, 313);
            this.metroLabel27.Name = "metroLabel27";
            this.metroLabel27.Size = new System.Drawing.Size(119, 15);
            this.metroLabel27.TabIndex = 60;
            this.metroLabel27.Text = "HypeSquad Settings";
            // 
            // gunaButton13
            // 
            this.gunaButton13.Animated = true;
            this.gunaButton13.AnimationHoverSpeed = 0.07F;
            this.gunaButton13.AnimationSpeed = 0.03F;
            this.gunaButton13.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton13.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton13.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton13.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton13.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton13.ForeColor = System.Drawing.Color.White;
            this.gunaButton13.Image = null;
            this.gunaButton13.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton13.Location = new System.Drawing.Point(18, 261);
            this.gunaButton13.Name = "gunaButton13";
            this.gunaButton13.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton13.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton13.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton13.OnHoverImage = null;
            this.gunaButton13.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton13.Size = new System.Drawing.Size(276, 42);
            this.gunaButton13.TabIndex = 34;
            this.gunaButton13.Text = "Select existing file";
            this.gunaButton13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton13.Click += new System.EventHandler(this.gunaButton13_Click);
            // 
            // gunaLineTextBox7
            // 
            this.gunaLineTextBox7.Animated = true;
            this.gunaLineTextBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaLineTextBox7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox7.FocusedLineColor = System.Drawing.Color.Red;
            this.gunaLineTextBox7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox7.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox7.LineSize = 1;
            this.gunaLineTextBox7.Location = new System.Drawing.Point(18, 227);
            this.gunaLineTextBox7.Name = "gunaLineTextBox7";
            this.gunaLineTextBox7.PasswordChar = '\0';
            this.gunaLineTextBox7.ReadOnly = true;
            this.gunaLineTextBox7.Size = new System.Drawing.Size(276, 26);
            this.gunaLineTextBox7.TabIndex = 33;
            this.gunaLineTextBox7.Text = "Insert path of your computer to save tokens here.";
            // 
            // siticoneCheckBox3
            // 
            this.siticoneCheckBox3.AutoSize = true;
            this.siticoneCheckBox3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox3.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox3.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox3.Location = new System.Drawing.Point(18, 205);
            this.siticoneCheckBox3.Name = "siticoneCheckBox3";
            this.siticoneCheckBox3.Size = new System.Drawing.Size(176, 17);
            this.siticoneCheckBox3.TabIndex = 31;
            this.siticoneCheckBox3.Text = "Save generated tokens to file";
            this.siticoneCheckBox3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox3.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox3.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox3.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox3.UseVisualStyleBackColor = true;
            // 
            // metroLabel24
            // 
            this.metroLabel24.AutoSize = true;
            this.metroLabel24.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel24.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel24.Location = new System.Drawing.Point(15, 184);
            this.metroLabel24.Name = "metroLabel24";
            this.metroLabel24.Size = new System.Drawing.Size(83, 15);
            this.metroLabel24.TabIndex = 30;
            this.metroLabel24.Text = "Save Settings";
            // 
            // gunaButton11
            // 
            this.gunaButton11.Animated = true;
            this.gunaButton11.AnimationHoverSpeed = 0.07F;
            this.gunaButton11.AnimationSpeed = 0.03F;
            this.gunaButton11.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton11.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton11.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton11.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton11.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton11.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton11.ForeColor = System.Drawing.Color.White;
            this.gunaButton11.Image = null;
            this.gunaButton11.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton11.Location = new System.Drawing.Point(18, 130);
            this.gunaButton11.Name = "gunaButton11";
            this.gunaButton11.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton11.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton11.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton11.OnHoverImage = null;
            this.gunaButton11.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton11.Size = new System.Drawing.Size(182, 42);
            this.gunaButton11.TabIndex = 28;
            this.gunaButton11.Text = "Reset proxies list";
            this.gunaButton11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton11.Click += new System.EventHandler(this.gunaButton11_Click);
            // 
            // metroLabel23
            // 
            this.metroLabel23.AutoSize = true;
            this.metroLabel23.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel23.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.metroLabel23.Location = new System.Drawing.Point(15, 109);
            this.metroLabel23.Name = "metroLabel23";
            this.metroLabel23.Size = new System.Drawing.Size(99, 15);
            this.metroLabel23.TabIndex = 27;
            this.metroLabel23.Text = "Loaded proxies: 0";
            this.metroLabel23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // gunaButton10
            // 
            this.gunaButton10.Animated = true;
            this.gunaButton10.AnimationHoverSpeed = 0.07F;
            this.gunaButton10.AnimationSpeed = 0.03F;
            this.gunaButton10.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton10.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton10.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton10.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton10.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton10.ForeColor = System.Drawing.Color.White;
            this.gunaButton10.Image = null;
            this.gunaButton10.ImageSize = new System.Drawing.Size(24, 24);
            this.gunaButton10.Location = new System.Drawing.Point(18, 61);
            this.gunaButton10.Name = "gunaButton10";
            this.gunaButton10.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.gunaButton10.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton10.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton10.OnHoverImage = null;
            this.gunaButton10.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton10.Size = new System.Drawing.Size(182, 42);
            this.gunaButton10.TabIndex = 26;
            this.gunaButton10.Text = "Load proxies list from file";
            this.gunaButton10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton10.Click += new System.EventHandler(this.gunaButton10_Click);
            // 
            // siticoneCheckBox1
            // 
            this.siticoneCheckBox1.AutoSize = true;
            this.siticoneCheckBox1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox1.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox1.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.siticoneCheckBox1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCheckBox1.Location = new System.Drawing.Point(18, 36);
            this.siticoneCheckBox1.Name = "siticoneCheckBox1";
            this.siticoneCheckBox1.Size = new System.Drawing.Size(85, 17);
            this.siticoneCheckBox1.TabIndex = 6;
            this.siticoneCheckBox1.Text = "Use proxies";
            this.siticoneCheckBox1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox1.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox1.UncheckedState.BorderThickness = 0;
            this.siticoneCheckBox1.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox1.UseVisualStyleBackColor = true;
            // 
            // metroLabel22
            // 
            this.metroLabel22.AutoSize = true;
            this.metroLabel22.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel22.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroLabel22.Location = new System.Drawing.Point(15, 14);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(97, 15);
            this.metroLabel22.TabIndex = 2;
            this.metroLabel22.Text = "Proxies Settings";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "Text file (*.txt)|*.txt";
            this.saveFileDialog1.Title = "Save generated tokens to file.";
            // 
            // MainForm
            // 
            this.AccentColor = System.Drawing.Color.Red;
            this.AllowResize = false;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(886, 674);
            this.Controls.Add(this.firefoxMainTabControl1);
            this.Controls.Add(this.gunaControlBox2);
            this.Controls.Add(this.gunaControlBox1);
            this.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.State = MetroSuite.MetroForm.FormState.Custom;
            this.Style = MetroSuite.Design.Style.Dark;
            this.Text = "AstarothGenerator V4";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.firefoxMainTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.ResumeLayout(false);

    }

    private Guna.UI.WinForms.GunaControlBox gunaControlBox1;
    private Guna.UI.WinForms.GunaControlBox gunaControlBox2;
    private FirefoxMainTabControl firefoxMainTabControl1;
    private System.Windows.Forms.TabPage tabPage1;
    private System.Windows.Forms.TabPage tabPage2;
    private MetroSuite.MetroLabel metroLabel1;
    private MetroSuite.MetroLabel metroLabel2;
    private MetroSuite.MetroLabel metroLabel3;
    private MetroSuite.MetroLabel metroLabel4;
    private MetroSuite.MetroLabel metroLabel5;
    private MetroSuite.MetroLabel metroLabel6;
    private MetroSuite.MetroLabel metroLabel9;
    private MetroSuite.MetroLabel metroLabel10;
    private MetroSuite.MetroLabel metroLabel7;
    private MetroSuite.MetroLabel metroLabel8;
    private MetroSuite.MetroLabel metroLabel11;
    private MetroSuite.MetroLabel metroLabel13;
    private MetroSuite.MetroLabel metroLabel12;
    private Guna.UI.WinForms.GunaButton gunaButton1;
    private Guna.UI.WinForms.GunaButton gunaButton4;
    private MetroSuite.MetroLabel metroLabel14;
    private Guna.UI.WinForms.GunaTextBox gunaTextBox1;
    private MetroSuite.MetroLabel metroLabel15;
    private ns1.SiticoneCheckBox siticoneCheckBox4;
    private ns1.SiticoneCheckBox siticoneCheckBox5;
    private MetroSuite.MetroLabel metroLabel16;
    private ns1.SiticoneCheckBox siticoneCheckBox6;
    private System.Windows.Forms.Panel panel1;
    private ns1.SiticoneRadioButton siticoneRadioButton1;
    private ns1.SiticoneRadioButton siticoneRadioButton2;
    private System.Windows.Forms.Panel panel2;
    private ns1.SiticoneRadioButton siticoneRadioButton4;
    private ns1.SiticoneCheckBox siticoneCheckBox7;
    private MetroSuite.MetroLabel metroLabel17;
    private ns1.SiticoneRadioButton siticoneRadioButton5;
    private ns1.SiticoneCheckBox siticoneCheckBox9;
    private MetroSuite.MetroLabel metroLabel18;
    private MetroSuite.MetroLabel metroLabel19;
    private System.Windows.Forms.Panel panel3;
    private ns1.SiticoneRadioButton siticoneRadioButton6;
    private ns1.SiticoneRadioButton siticoneRadioButton7;
    private ns1.SiticoneRadioButton siticoneRadioButton8;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox1;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox2;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox3;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox4;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox5;
    private Guna.UI.WinForms.GunaButton gunaButton2;
    private Guna.UI.WinForms.GunaButton gunaButton3;
    private Guna.UI.WinForms.GunaButton gunaButton5;
    private Guna.UI.WinForms.GunaButton gunaButton6;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox6;
    private System.Windows.Forms.Panel panel4;
    private ns1.SiticoneRadioButton siticoneRadioButton9;
    private ns1.SiticoneRadioButton siticoneRadioButton10;
    private ns1.SiticoneRadioButton siticoneRadioButton11;
    private MetroSuite.MetroLabel metroLabel20;
    private Guna.UI.WinForms.GunaButton gunaButton7;
    private Guna.UI.WinForms.GunaButton gunaButton8;
    private System.Windows.Forms.Panel panel5;
    private ns1.SiticoneRadioButton siticoneRadioButton12;
    private ns1.SiticoneRadioButton siticoneRadioButton13;
    private MetroSuite.MetroLabel metroLabel21;
    private Guna.UI.WinForms.GunaButton gunaButton9;
    private System.Windows.Forms.TabPage tabPage3;
    private MetroSuite.MetroLabel metroLabel22;
    private ns1.SiticoneCheckBox siticoneCheckBox1;
    private Guna.UI.WinForms.GunaButton gunaButton10;
    private MetroSuite.MetroLabel metroLabel23;
    private Guna.UI.WinForms.GunaButton gunaButton11;
    private MetroSuite.MetroLabel metroLabel24;
    private ns1.SiticoneCheckBox siticoneCheckBox3;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox7;
    private Guna.UI.WinForms.GunaButton gunaButton13;
    private ns1.SiticoneSlider siticoneSlider1;
    private MetroSuite.MetroLabel metroLabel27;
    private System.Windows.Forms.Panel panel7;
    private ns1.SiticoneRadioButton siticoneRadioButton27;
    private ns1.SiticoneRadioButton siticoneRadioButton28;
    private MetroSuite.MetroLabel metroLabel28;
    private System.Windows.Forms.Panel panel8;
    private ns1.SiticoneRadioButton siticoneRadioButton26;
    private ns1.SiticoneRadioButton siticoneRadioButton29;
    private ns1.SiticoneRadioButton siticoneRadioButton30;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox8;
    private ns1.SiticoneComboBox siticoneComboBox1;
    private Guna.UI.WinForms.GunaButton gunaButton14;
    private Guna.UI.WinForms.GunaButton gunaButton15;
    private Guna.UI.WinForms.GunaButton gunaButton16;
    private System.Windows.Forms.OpenFileDialog openFileDialog1;
    private MetroSuite.MetroLabel metroLabel25;
    private MetroSuite.MetroLabel metroLabel26;
    private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
    private ns1.SiticoneCheckBox siticoneCheckBox13;
    private ns1.SiticoneCheckBox siticoneCheckBox14;
    private ns1.SiticoneCheckBox siticoneCheckBox15;
    private MetroSuite.MetroLabel metroLabel29;
    private MetroSuite.MetroLabel metroLabel30;
    private MetroSuite.MetroLabel metroLabel31;
    private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox9;
    private ns1.SiticoneCheckBox siticoneCheckBox2;
    private MetroSuite.MetroLabel metroLabel32;
}