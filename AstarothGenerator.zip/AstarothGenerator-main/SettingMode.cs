﻿public enum SettingMode
{
    Random, Specified, Listed
}