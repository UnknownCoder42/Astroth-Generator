﻿public static class GlobalVariables
{
    public static int tokensGenerated = 0, captchaSuccess = 0, captchaFails = 0, generationFails = 0, operationsExecuted = 0;
}