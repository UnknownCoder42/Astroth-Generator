﻿public enum ServiceCaptcha
{
    TwoCaptcha, CapMonster
}